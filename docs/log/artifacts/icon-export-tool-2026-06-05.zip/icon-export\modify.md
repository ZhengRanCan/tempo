1. 最大问题：--group 仍然写死了几个 group

现在 export_icons.py 里有：

DEFAULT_MANIFESTS = {
    "tab": ROOT / "static" / "icons" / "tab" / "icon-spec.json",
    "page/today": ROOT / "static" / "icons" / "page" / "today" / "icon-spec.json",
    "common": ROOT / "static" / "icons" / "common" / "icon-spec.json",
}
运行

这意味着它只认识：

tab
page/today
common

如果你后面新增：

page/calendar
page/profile
page/create

然后运行：

python tools/icon-export/export_icons.py validate --group page/calendar

它会报 unknown group。这个不符合你现在想要的“根据 static/icons/<group>/icon-spec.json 自动读取”的设计。

建议改成：

def manifest_for_group(group: str) -> Path:
    group_path = Path(group)

    if group_path.is_absolute() or ".." in group_path.parts:
        raise ValueError(f"invalid group: {group}")

    manifest = (ROOT / "static" / "icons" / group_path / "icon-spec.json").resolve()

    static_icons_root = (ROOT / "static" / "icons").resolve()
    try:
        manifest.relative_to(static_icons_root)
    except ValueError as exc:
        raise ValueError(f"group must resolve under static/icons/: {group}") from exc

    return manifest
运行

这样：

--group tab
→ static/icons/tab/icon-spec.json

--group page/today
→ static/icons/page/today/icon-spec.json

--group page/calendar
→ static/icons/page/calendar/icon-spec.json

后续新增 group 就不用改脚本了。

2. validate 没检查 format 和 background

你的 manifest 里会写：

"format": "png",
"background": "transparent"

但当前脚本没有校验这两个字段。实际导出一定是 PNG 透明背景，因为 IconConverter 里写死了透明 RGBA 画布，但 manifest 如果写错，validate 不会提醒。

建议加：

def validate_format_and_background(manifest: dict) -> None:
    fmt = manifest.get("format", "png")
    if fmt != "png":
        raise ValueError("manifest format must be png")

    bg = manifest.get("background", "transparent")
    if bg != "transparent":
        raise ValueError("manifest background must be transparent")

然后在 validate_manifest() 里调用。

这不是致命 bug，但能避免 spec 写错后没人发现。

3. 输出文件重复检查建议用完整相对路径，不要只用文件名

现在是：

output_names = [plan.output_png.name for plan in plans]

这会只拿文件名，比如 star.png。如果未来某个 manifest 支持子目录，例如：

section/star.png
status/star.png

它会误判重复，或者如果路径逻辑变化，也不够准确。

建议改成检查完整输出路径：

output_keys = [str(plan.output_png.resolve()) for plan in plans]
duplicates = sorted({key for key in output_keys if output_keys.count(key) > 1})

或者相对输出目录：

out_dir = output_dir(manifest)
output_keys = [plan.output_png.relative_to(out_dir).as_posix() for plan in plans]

当前不改也能用，但以后扩展更稳。

4. variants 只支持 palette key，不支持直接 hex

现在 variant 逻辑是：

"variants": {
  "default": "default",
  "active": "active"
}

这里的 "default" 和 "active" 必须是 palette 里的 key。这个设计没问题。

但如果以后你想写：

"variants": {
  "default": "#8A8176",
  "active": "#6B5BEA"
}

当前脚本会把 #8A8176 当作 paletteRef，然后报错。这个不是 bug，只是要在 README 里写清楚：

variants 的值必须是 palette 中的 key，不支持直接写 hex。

或者你也可以增强脚本，让 variants 同时支持 palette key 和 hex color。不过现在不一定需要，别把工具弄太花。

## 精简版本：
继续修 tools/icon-export/export_icons.py 和 tools/icon-export/README.md：

1. 移除 DEFAULT_MANIFESTS 硬编码映射。
   --group 应按以下规则自动推导 manifest：
   --group tab → static/icons/tab/icon-spec.json
   --group page/today → static/icons/page/today/icon-spec.json
   --group page/calendar → static/icons/page/calendar/icon-spec.json

2. group 必须是相对路径，不能是绝对路径，不能包含 ".."。
   推导出的 manifest 必须位于 static/icons/ 下。

3. validate_manifest 增加校验：
   - format 必须是 png，默认 png；
   - background 必须是 transparent，默认 transparent。

4. 输出文件重复检查改为检查完整输出路径或相对 output directory 的路径，不要只用 output_png.name。

5. README 说明：
   - --group 是按 static/icons/<group>/icon-spec.json 自动推导；
   - variants 的值默认是 palette key；
   - SVG 原始颜色会被忽略，只保留形状和透明度；
   - 最终颜色由 icon-spec.json 决定。

不要修改页面、components、services、models、app.json、pages.json 或业务逻辑。